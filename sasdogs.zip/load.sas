filename P2ED0E87 list;

 %put NOTE- ;
 %put NOTE: Loading package SASDoGs, version 0.3, license MIT; 
 %put NOTE: *** %superq(packageTitle) ***; 
 %put NOTE- Generated: 2026-06-07T21:22:03; 
 %put NOTE- Author(s): %superq(packageAuthor); 
 %put NOTE- Maintainer(s): %superq(packageMaintainer); 
 %put NOTE- ;
 %put NOTE- Run %nrstr(%%)helpPackage(SASDoGs) for the description;
 %put NOTE- ;
 %put NOTE- *** START ***; 

data _null_; 
 if NOT ("*"=symget("cherryPick")) then do; 
  put "NOTE- "; 
  put "NOTE: *** Cherry Picking ***"; 
  put "NOTE- Cherry Picking in action!! Be advised that"; 
  put "NOTE- dependencies/required packages will not be loaded!"; 
  put "NOTE- "; 
 end; 
run; 
%include  P2ED0E87(packagemetadata.sas) / nosource2; 

 data _null_;                                                     
  call symputX("packageRequiredErrors", 0, "L");                  
 run;                                                             
 %put NOTE- *Testing required SAS components*%sysfunc(DoSubL(
 options nonotes nosource %str(;)                            
 options ls=max ps=max locale=en_US %str(;)                  
 /* temporary redirect log */                                
 filename _stinit_ TEMP %str(;)                              
 proc printto log = _stinit_ %str(;) run %str(;)             
 /* print out setinit */                                     
 proc setinit %str(;) run %str(;)                            
 proc printto %str(;) run %str(;)                            
 options ps=min %str(;)                                      
 data _null_ %str(;)                                         
   /* loadup checklist of required SAS components */         
   if _n_ = 1 then                                           
     do %str(;)                                              
       length req $ 256 %str(;)                              
       declare hash R() %str(;)                              
       _N_ = R.defineKey("req") %str(;)                      
       _N_ = R.defineDone() %str(;)                          
       declare hiter iR("R") %str(;)                         
         do req = %bquote(
"BASE SAS SOFTWARE"
) %str(;)   
          _N_ = R.add(key:req,data:req) %str(;)              
         end %str(;)                                         
     end %str(;)                                             
                                                             
   /* read in output from proc setinit */                    
   infile _stinit_ end=eof %str(;)                           
   input %str(;)                                             
                                                             
   /* if component is in setinit remove it from checklist */ 
   if _infile_ =: "---" then                                 
     do %str(;)                                              
       req = upcase(substr(_infile_, 4, 64)) %str(;)         
       if R.find(key:req) = 0 then                           
         do %str(;)                                          
           _N_ = R.remove() %str(;)                          
         end %str(;)                                         
     end %str(;)                                             
                                                             
   /* if checklist is not null rise error */                 
   if eof and R.num_items > 0 then                           
     do %str(;)                                              
       put "WARNING- ###########################################" %str(;) 
       put "WARNING:  The following SAS components are missing! " %str(;) 
       call symputX("packageRequiredErrors", 0, "L") %str(;)              
       do while(iR.next() = 0) %str(;)                                    
         put "WARNING-   " req %str(;)                                    
       end %str(;)                                                        
       put "WARNING:  The package may NOT WORK as expected      " %str(;) 
       put "WARNING:  or even result with ERRORS!               " %str(;) 
       put "WARNING- ###########################################" %str(;) 
       put %str(;)                                           
     end %str(;)                                             
 run %str(;)                                                 
 filename _stinit_ clear %str(;)                             
 options notes source %str(;)                                
 ))*;                                                        
 %let temp_noNotes_etc=%sysfunc(getoption(NOTES));
 options noNotes;
 data _null_;                                                     
  if 1 = symgetn("packageRequiredErrors") then                    
    do;                                                           
      put "ERROR: Loading package &packageName. will be aborted!";
      put "ERROR- Required components are missing.";              
      put "ERROR- *** STOP ***";                                  
      call symputX("packageRequiredErrors",
     'options ls = &ls_tmp. ps = &ps_tmp. 
       &notes_tmp. &source_tmp. msglevel=&msglevel_tmp. 
       &stimer_tmp. &fullstimer_tmp. ;
       data _null_;abort;run;', "L");              
    end;                                            
  else                                              
    call symputX("packageRequiredErrors", " ", "L");
 run;                                               
 &packageRequiredErrors.                            
 options &temp_noNotes_etc.;                        
 
%if (%str(*)=%superq(cherryPick)) or (_indexmd in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "_indexmd.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(_indexmd)=1, NOTE# Macro _indexmd exist. It will be overwritten by the macro from the SASDoGs package, ));
  %include P2ED0E87(_macro._indexmd.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (_inner in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "_inner.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(_inner)=1, NOTE# Macro _inner exist. It will be overwritten by the macro from the SASDoGs package, ));
  %include P2ED0E87(_macro._inner.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (_mystdoc in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "_mystdoc.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(_mystdoc)=1, NOTE# Macro _mystdoc exist. It will be overwritten by the macro from the SASDoGs package, ));
  %include P2ED0E87(_macro._mystdoc.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (_spfdoc in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "_spfdoc.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(_spfdoc)=1, NOTE# Macro _spfdoc exist. It will be overwritten by the macro from the SASDoGs package, ));
  %include P2ED0E87(_macro._spfdoc.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (_sphinxdoc in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "_sphinxdoc.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(_sphinxdoc)=1, NOTE# Macro _sphinxdoc exist. It will be overwritten by the macro from the SASDoGs package, ));
  %include P2ED0E87(_macro._sphinxdoc.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (collectfiles in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "collectfiles.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(collectfiles)=1, NOTE# Macro collectfiles exist. It will be overwritten by the macro from the SASDoGs package, ));
  %include P2ED0E87(_macro.collectfiles.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (generatemd in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "generatemd.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(generatemd)=1, NOTE# Macro generatemd exist. It will be overwritten by the macro from the SASDoGs package, ));
  %include P2ED0E87(_macro.generatemd.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (generatenb in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "generatenb.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(generatenb)=1, NOTE# Macro generatenb exist. It will be overwritten by the macro from the SASDoGs package, ));
  %include P2ED0E87(_macro.generatenb.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (packagedoc in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "packagedoc.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(packagedoc)=1, NOTE# Macro packagedoc exist. It will be overwritten by the macro from the SASDoGs package, ));
  %include P2ED0E87(_macro.packagedoc.sas) / nosource2;
%end; 

data _null_;                                   
  call symputX("cherryPick_CASLUDF",  0, "L"); 
run;                                           
data _null_;                                   
length CASLUDF $ 32767;                        
dtCASLudf = datetime();                        
CASLUDF =                                      
    '%macro SASDoGsCASLudf('         
 !! "list=1,depList="                          
 !! ')/ des = ''CASL User Defined Functions loader for SASDoGs package'';'
 !! '  %if HELP = %superq(list) %then                               '
 !! '    %do;                                                       '
 !! '      %put ****************************************************************************;'
 !! '      %put This is help for the `SASDoGsCASLudf` macro;'
 !! '      %put Parameters (optional) are the following:;'
 !! '      %put - `list` indicates if the list of loaded CASL UDFs should be displayed,;'
 !! '      %put %str(  )when set to the value of `1` (the default) runs `FUNCTIONLIST USER%str(;)`,;'
 !! '      %put %str(  )when set to the value of `HELP` (upcase letters!) displays this help message.;'
 !! '      %put - `depList` [technical] contains the list of dependencies required by the package.;'
 !! '      %put %str(  )for _this_ instance of the macro the default value is: `.;'
 !! '      %put The macro generated: ' !! put(dtCASLudf, E8601DT19.-L) !! ";"
 !! '      %put with the SAS Packages Framework version 20260602.;'
 !! '      %put ****************************************************************************;'
 !! '    %GOTO theEndOfTheMacro;'
 !! '    %end;'
 !! '  %if %superq(depList) ne %then                                '
 !! '    %do;                                                       '
 !! '      %do i = 1 %to %sysfunc(countw(&depList.,%str( )));       '
 !! '        %let depListNm = %scan(&depList.,&i.,%str( ));         '
 !! '        %if %SYSMACEXIST(&depListNm.CASLudf) %then             '
 !! '          %do;                                                 '
 !! '            %&depListNm.CASLudf(list=0)                        '
 !! '          %end;                                                '
 !! '      %end;                                                    '
 !! '    %end;                                                      '
 !! '  %local tmp_NOTES;'                           
 !! '  %let tmp_NOTES = %sysfunc(getoption(NOTES));'
 !! "  filename P2ED0E87 &ZIP. '&path./sasdogs.&zip.';"
 !! "  options nonotes;"                      
 !! '  filename P2ED0E87 clear;'    
 !! '  options &tmp_NOTES.;'                
 !! '   %if 1 = %superq(list) %then '       
 !! '     %do; '                            
 !! "       FUNCTIONLIST USER;"               
 !! "       run;"                             
 !! '     %end; '                           
 !! '%theEndOfTheMacro: %mend;';            
run;

data _null_;
run;
data _null_;
run;
%if (%str(*)=%superq(cherryPick)) %then %do;
proc fcmp outlib = work.SASDoGsfcmp.packagemeta ; 
 function SASDoGsMETA(meta $) $ 32767;
  m = char(upcase(meta),1);
   if m = 'V' then return(strip("0.3"));
   if m = 'D' then return(strip("2026-06-07T21:22:03"));
   if m = 'A' then return(strip("Ken Nakamatsu (ken-nakamatsu@knworx.com)"));
   if m = 'M' then return(strip("Ken Nakamatsu (ken-nakamatsu@knworx.com)"));
   if m = 'T' then return(strip("SAS Documentation Generator system"));
   if m = 'E' then return(strip("UTF8"));
   if m = 'L' then return(strip("2026-06-07T21:22:03"));
   if m = 'S' then return(strip("""BASE SAS SOFTWARE"""));
  return(" ");
 endfunc;
quit;
%sysfunc(ifc(0<
  %sysfunc(findw((%sysfunc(getoption(cmplib)))
                ,work.sasdogsfcmp,"'( )'",RIO))
,,%str(options APPEND=(cmplib = work.sasdogsfcmp);)
))
%macro SASDoGsMETA(meta)/parmbuff;
%if %superq(meta) = %then %return;
%do;%qsysfunc(strip(%qsysfunc(SASDoGsMETA&syspbuff.)))%end;
%mend;


%end;
%put NOTE- ;
%put NOTE:[CMPLIB] %sysfunc(getoption(cmplib));

%if (%str(*)=%superq(cherryPick)) %then %do; 
 %let temp_noNotes_etc=%sysfunc(getoption(NOTES));
 options noNotes;
 data _null_ ;                                                                                              
  length SYSloadedPackages stringPCKG $ 32767;                                                              
  if SYMEXIST("SYSloadedPackages") = 1 and SYMGLOBL("SYSloadedPackages") = 1 then                           
    do;                                                                                                     
      do until(EOF);                                                                                        
        set sashelp.vmacro(where=(scope="GLOBAL" and name="SYSLOADEDPACKAGES")) end=EOF;                    
        substr(SYSloadedPackages, 1+offset, 200) = value;                                                   
      end;                                                                                                  
      SYSloadedPackages = cats("#", translate(strip(SYSloadedPackages), "#", " "), "#");                    
      indexPCKG = INDEX(lowcase(SYSloadedPackages), '#sasdogs(');                  
      if indexPCKG = 0 then                                                                                 
         do;                                                                                                
          SYSloadedPackages = catx('#', SYSloadedPackages, 'SASDoGs(0.3)');              
          SYSloadedPackages = compbl(translate(SYSloadedPackages, " ", "#"));                               
          call symputX("SYSloadedPackages", SYSloadedPackages, "G");                                        
          put / "INFO: [SYSLOADEDPACKAGES] " SYSloadedPackages ;                                             
         end ;                                                                                              
      else                                                                                                  
         do;                                                                                                
          stringPCKG = kscanx(substr(SYSloadedPackages, indexPCKG+1), 1, '#');                              
          SYSloadedPackages = compbl(tranwrd(SYSloadedPackages, strip(stringPCKG), "#"));                   
          SYSloadedPackages = catx('#', SYSloadedPackages, 'SASDoGs(0.3)');              
          SYSloadedPackages = compbl(translate(SYSloadedPackages, " ", "#"));                               
          call symputX("SYSloadedPackages", SYSloadedPackages, "G");                                        
          put / "INFO: [SYSLOADEDPACKAGES] " SYSloadedPackages ;                                             
         end ;                                                                                              
    end;                                                                                                    
  else                                                                                                      
    do;                                                                                                     
      call symputX('SYSloadedPackages', 'SASDoGs(0.3)', 'G');                            
      put / 'INFO: [SYSLOADEDPACKAGES] SASDoGs(0.3)';                                     
    end;                                                                                                    
  stop;                                                                                                     
 run;                                                                                                       
 options &temp_noNotes_etc.;
%end; 

options NOTES;
%put NOTE- ;
%put NOTE: Loading package SASDoGs, version 0.3, license MIT;
%put NOTE- *** END ***;

options &temp_noNotes_etc.;
%symdel temp_noNotes_etc / noWarn;
/* load.sas end */

