filename P2ED0E87 list;
 %put NOTE- ;
 %put NOTE: Data for package SASDoGs, version 0.3, license MIT; 
 %put NOTE: *** %superq(packageTitle) ***; 
 %put NOTE- Generated: 2026-06-07T21:22:03; 
 %put NOTE- Author(s): %superq(packageAuthor); 
 %put NOTE- Maintainer(s): %superq(packageMaintainer); 
 %put NOTE- ;
 %put NOTE- Write %nrstr(%%)helpPackage(SASDoGs) for the description;
 %put NOTE- ;
 %put NOTE- *** START ***; 

data _null_;
 length lazyData $ 32767; lazyData = lowcase(symget("lazyData"));
run;
%put NOTE- ;
%put NOTE: Data for package SASDoGs, version 0.3, license MIT;
%put NOTE- *** END ***;
/* lazydata.sas end */
